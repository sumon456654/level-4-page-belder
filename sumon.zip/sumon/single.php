<?php get_header();?>


<div class="container">
    <div class="title">
        <?php the_title();?>
    </div>
<div class="header_cont">
    <?php the_author();?>
</div>
<div class="div">
<?php the_post_thumbnail();?>
</div>
<div class="div">
    <?php the_content();?>
</div>

</div>
<?php get_footer();?>