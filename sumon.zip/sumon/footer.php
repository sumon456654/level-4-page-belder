

<footer class="container">
    <div class="row">
        <div class="col-sm-6">1</div>
        <div class="col-sm-6">2</div>
    </div>
</footer>
<?php wp_footer();?>
    
</body>
</html>